## Présentation

Ces contenaires ont été initialement issus de https://github.com/kiwenlau/hadoop-cluster-docker

Un cluster de trois contenaires est créé, avec comme plateformes installées:

  * [Apache Hadoop](http://hadoop.apache.org/) Version: 2.7.2
  * [Apache Spark](https://spark.apache.org/) Version: 2.2.1
  * [Apache Kafka](https://kafka.apache.org/) Version 2.11-1.0.2 
  * [Apache HBase](https://hbase.apache.org/) Version 1.4.8

Pour des tutoriaux détaillés sur la façon d'utiliser ces contenaires, visiter:
https://insatunisia.github.io/TP-BigData

Bonne lecture!
